# ZED-F9P Configuration Files

## REMARKS
The configuration files may not work when used together with ODIN-W2 Mbed Application Firmware. This is due to the C099-F9P interface configurations which depend on the current ODIN-W2 Firmware in use.
 

